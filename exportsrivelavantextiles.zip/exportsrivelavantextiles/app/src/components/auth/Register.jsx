import React, { useState } from 'react'
import { auth, db } from '../../firebase'
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { ref, serverTimestamp, set } from 'firebase/database';
import Swal from 'sweetalert2';


const Register = ({ GoToLogin, SetLoginPage }) => {
    const [passwordVisible, setPasswordVisible] = useState(false);
    const handleTogglePassword = () => {
        setPasswordVisible((prevVisible) => !prevVisible);
    };
    const [formData, setFormData] = useState({
        name: '',
        phone: '',
        email: '',
        password: '',
        city: '',
        state: '',
        address: '',
        pincode: ''
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };


    const handleSubmit = async (e) => {
        e.preventDefault();
        Swal.fire({
            html: `
              <div class="p-5" >
                <div class="spinner-border text-dark" role="status">
                  <span class="visually-hidden">Loading...</span>
                </div>
              </div>
            `,
            showConfirmButton: false,
            background: 'transparent',
        });
        try {
            const userCredential = await createUserWithEmailAndPassword(auth, formData.email, formData.password);
            const user = userCredential.user;
            console.log(user);
            set(ref(db, `users/${user.uid}/profiledetails`), {
                name: formData.name,
                email: formData.email,
                phone: formData.phone,
                city: formData.city,
                state: formData.state,
                pincode: formData.pincode,
                address: formData.address,
                role: "user",
                accountcreatedat: serverTimestamp(),
            });
            Swal.fire({
                icon: 'success',
                title: 'Successfully Registered',
                showConfirmButton: true, confirmButtonColor: 'black',
            })
            SetLoginPage()
        } catch (error) {
            const errorCode = error.code;
            if (errorCode === "auth/email-already-in-use") {
                Swal.fire({
                    icon: 'error',
                    title: 'Account Already Exists',
                    showConfirmButton: true, confirmButtonColor: 'black',
                    timer: 1500
                })
            } else if (errorCode === "auth/invalid-email") {
                Swal.fire({
                    icon: 'error',
                    title: 'Invalid Email',
                    showConfirmButton: true, confirmButtonColor: 'black',
                    timer: 3000
                })
            } else if (errorCode === "auth/operation-not-allowed") {
                Swal.fire({
                    icon: 'error',
                    title: 'Operation Not Allowed',
                    showConfirmButton: true, confirmButtonColor: 'black',
                    timer: 1500
                })
            } else if (errorCode === "auth/weak-password") {
                Swal.fire({
                    icon: 'warning',
                    title: 'Your Password is too Weak',
                    showConfirmButton: true, confirmButtonColor: 'black',
                    timer: 1500
                })
            }
        }
    };
    return (
        <div>  <form className='d-flex flex-row justify-content-center' onSubmit={handleSubmit}>
            <div className='d-flex flex-column'>
                <h1 className='text-center display-2 animate__animated animate__zoomIn text-uppercase'>Register</h1><br />
                <div className='input-group mb-3 animate__animated animate__zoomIn'>
                    <span className=' input-group-text  rounded-start-3  border-1 border-end-0'><i className='bi bi-person-fill'></i></span>
                    <input name='name'
                        value={formData.name}
                        onChange={handleChange} className='form-control border shadow-none rounded-end-3  border-start-0 border-1' placeholder='Enter your Name' type='text' required />
                </div>
                <div className='input-group mb-3 animate__animated animate__zoomIn'>
                    <span className=' input-group-text  rounded-start-3  border-1 border-end-0'><i className='bi bi-123'></i></span>
                    <input name='phone'
                        value={formData.phone}
                        onChange={handleChange} className='form-control border shadow-none rounded-end-3  border-start-0 border-1' placeholder='Enter your Phone Number' type='number' required />
                </div>
                <div className='input-group mb-3 animate__animated animate__zoomIn'>
                    <span className=' input-group-text  rounded-start-3  border-1 border-end-0'><i className='bi bi-map-fill'></i></span>
                    <input name='city'
                        value={formData.city}
                        onChange={handleChange} className='form-control border shadow-none rounded-end-3  border-start-0 border-1' placeholder='Enter your City' type='text' required />
                </div>
                <div className='input-group mb-3 animate__animated animate__zoomIn'>
                    <span className=' input-group-text  rounded-start-3  border-1 border-end-0'><i className='bi bi-map-fill'></i></span>
                    <input name='state'
                        value={formData.state}
                        onChange={handleChange} className='form-control border shadow-none rounded-end-3  border-start-0 border-1' placeholder='Enter your State' type='text' required />
                </div>
                <div className='input-group mb-3 animate__animated animate__zoomIn'>
                    <span className=' input-group-text  rounded-start-3  border-1 border-end-0'><i className='bi bi-geo-fill'></i></span>
                    <input name='pincode'
                        value={formData.pincode}
                        onChange={handleChange} className='form-control border shadow-none rounded-end-3  border-start-0 border-1' placeholder='Enter your Pincode' type='text' required />
                </div>
                <div className='input-group mb-3 animate__animated animate__zoomIn'>
                    <span className=' input-group-text  rounded-start-3  border-1 border-end-0'><i className='bi bi-crosshair'></i></span>
                    <input name='address'
                        value={formData.address}
                        onChange={handleChange} className='form-control border shadow-none rounded-end-3  border-start-0 border-1' placeholder='Enter your Address' type='text' required />
                </div>
                <div className='input-group mb-3 animate__animated animate__zoomIn '>
                    <span className=' input-group-text  rounded-start-3  border-1 border-end-0'><i className='bi bi-envelope-fill'></i></span>
                    <input name='email'
                        value={formData.email}
                        onChange={handleChange} className='form-control border shadow-none rounded-end-3  border-start-0 border-1' placeholder='Enter your Email' type='email' required />
                </div>
                <div className='input-group mb-3 animate__animated animate__zoomIn'>
                    <span className='input-group-text'>
                        <i className='bi bi-lock-fill'></i>
                    </span>
                    <input
                        name='password'
                        value={formData.password}
                        onChange={handleChange}

                        placeholder='Enter your Password'
                        type={passwordVisible ? 'text' : 'password'}
                        className='form-control border border-start-0 border-end-0 shadow-none'
                        autoComplete
                        required
                    />
                    <span className='input-group-text' onClick={handleTogglePassword}>
                        <i className={`bi bi-eye${passwordVisible ? '-slash-fill' : '-fill'}`}></i>
                    </span>
                </div>
                <button type='submit' className='btn btn-dark rounded-3 border-0 animate__animated animate__zoomIn  mb-5' >Register</button>
                <div className='text-center my-3 mb-4 fw-bold animate__animated animate__zoomIn'>Already Have an account ? <span onClick={GoToLogin}>Login</span> </div>

            </div>
        </form>
        </div>
    )
}

export default Register