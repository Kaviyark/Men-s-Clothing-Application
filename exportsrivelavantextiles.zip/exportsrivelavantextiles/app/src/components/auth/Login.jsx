import React, { useState } from 'react'
import { auth, db } from '../../firebase'
import { signInWithEmailAndPassword } from 'firebase/auth';
import Swal from 'sweetalert2';
import { onValue, ref } from 'firebase/database';
const Login = ({ GoToRegister, SetLoginPage, SetForgotPassword }) => {
    const [formData, setFormData] = useState({
        email: '',
        password: '',
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const [passwordVisible, setPasswordVisible] = useState(false);


    const handleTogglePassword = () => {
        setPasswordVisible((prevVisible) => !prevVisible);
    };


    const handleSubmit = (e) => {
        e.preventDefault();
        Swal.fire({
            html: `
              <div class="p-5" >
                <div class="spinner-border text-dark" role="status">
                  <span class="visually-hidden">Loading...</span>
                </div>
              </div>
            `,
            showConfirmButton: false,
            background: 'transparent',
        });


        signInWithEmailAndPassword(auth, formData.email, formData.password)
            .then((userCredential) => {
                const user = userCredential.user;
                const uid = user.uid;

                const userinforef = ref(db, 'users/' + uid + '/profiledetails');
                onValue(userinforef, (snapshot) => {
                    const data = snapshot.val();

                    if (data.role === "user") {
                        Swal.fire({
                            icon: 'success',
                            title: 'Logged in Successfully',
                            showConfirmButton: true,
                            timer: 3000
                        })
                        SetLoginPage();
                    }
                    else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Email or Password is Wrong',
                            showConfirmButton: true,
                            timer: 3000
                        })
                        auth.signOut();
                    }
                });


            })
            .catch((error) => {
                const errorCode = error.code;
                if (errorCode === "auth/invalid-login-credentials") {
                    Swal.fire({
                        icon: 'error',
                        title: 'Email or Password is Wrong',
                        showConfirmButton: true,
                        timer: 3000
                    })
                }


            });
    };
    return (
        <div>
            <form className='d-flex flex-row justify-content-center' onSubmit={handleSubmit}>
                <div className='d-flex flex-column'>
                    <h1 className='text-center display-2 animate__animated animate__zoomIn text-uppercase'>Login</h1><br />

                    <div className='input-group mb-3 animate__animated animate__zoomIn'>
                        <span className=' input-group-text  rounded-start-3  border-1 border-end-0'><i className='bi bi-envelope-fill'></i></span>
                        <input className='form-control border shadow-none rounded-end-3  border-start-0 border-1' placeholder='Enter your Email' type='email' name="email"
                            value={formData.email}
                            onChange={handleChange} required />
                    </div>
                    <div className='input-group mb-3 w-100 animate__animated animate__zoomIn '>
                        <span className='input-group-text'>
                            <i className='bi bi-lock-fill'></i>
                        </span>
                        <input
                            name="password"
                            value={formData.password}
                            onChange={handleChange}
                            placeholder='Enter your Password'
                            type={passwordVisible ? 'text' : 'password'}
                            className='form-control shadow-none'
                            required

                        />
                        <span className='input-group-text' onClick={handleTogglePassword}>
                            <i className={`bi bi-eye${passwordVisible ? '-slash-fill' : '-fill'}`}></i>
                        </span>
                    </div>
                    <div onClick={SetForgotPassword} className='text-center my-3 mb-4 fw-bold animate__animated animate__zoomIn'>Forgot Password ? </div>
                    <button type='submit' className='btn btn-dark rounded-3 border-0 animate__animated animate__zoomIn mb-5'>Login</button>
                    <div className='text-center my-3 mb-4 fw-bold animate__animated animate__zoomIn'>Don't Have an account ? <span onClick={GoToRegister}>Register</span> </div>
                </div>
            </form>
        </div>
    )
}

export default Login