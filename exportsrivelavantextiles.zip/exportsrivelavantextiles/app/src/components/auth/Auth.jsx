import React, { useEffect, useState } from 'react'
import Login from './Login';
import Register from './Register';
import ForgotPassword from './ForgotPassword';

const Auth = ({ SetLoginPage }) => {
    const [activeComponent, setActiveComponent] = useState("Login");

    const renderActiveComponent = () => {
        switch (activeComponent) {
            case "Login":
                return <Login GoToRegister={GoToRegister} SetLoginPage={SetLoginPage} SetForgotPassword={SetForgotPassword} />;
            case "Register":
                return <Register GoToLogin={GoToLogin} SetLoginPage={SetLoginPage} />;
            case "Forgot Password":
                return <ForgotPassword GoToLogin={GoToLogin} />;
        }
    };
    const GoToRegister = () => {
        setActiveComponent("Register")
    }
    const GoToLogin = () => {
        setActiveComponent("Login")
    }
    const SetForgotPassword = () => {
        setActiveComponent("Forgot Password")
    }






    return (
        <div>
            {renderActiveComponent()}
        </div>




    )
}

export default Auth