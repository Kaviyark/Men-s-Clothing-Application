import React, { useEffect, useState } from 'react';
import { ref, child, get, remove, update, push } from 'firebase/database';
import { db, storage } from '../firebase';
import { deleteObject, ref as reference } from 'firebase/storage';
import Swal from 'sweetalert2';

import qrcode from '../assets/qr-code.png'
const Products = ({ userData, userUID }) => {
    const [addproduct, setaddproduct] = useState(false);
    const [products, setProducts] = useState({});
    const [selectedProduct, setSelectedProduct] = useState(null);
    const [isViewModalOpen, setIsViewModalOpen] = useState(false);




    useEffect(() => {
        const dbRef = ref(db);

        get(child(dbRef, 'products/'))
            .then((snapshot) => {
                if (snapshot.exists()) {
                    const productData = snapshot.val();
                    setProducts(productData);
                } else {
                    console.log('No data available');
                }
            })
            .catch((error) => {
                console.error(error);
            });
    }, []);



    const AddProductComponent = () => {
        setaddproduct(!addproduct);
    };



    const fetchproducts = () => {
        const dbRef = ref(db);
        get(child(dbRef, 'products/'))
            .then((snapshot) => {
                if (snapshot.exists()) {
                    const productData = snapshot.val();
                    setProducts(productData);
                } else {
                    console.log('No data available');
                }
            })
            .catch((error) => {
                console.error(error);
            });
    }







    const deleteProduct = (productId) => {
        Swal.fire({
            title: 'Delete Product',
            text: 'Are you sure you want to delete this product?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Delete',
            cancelButtonText: 'Cancel',
        }).then((result) => {
            if (result.isConfirmed) {
                if (typeof productId === 'string') {
                    Swal.fire({
                        html: `
              <div className="p-5" >
                <div className="spinner-border text-dark" role="status">
                  <span className="visually-hidden">Loading...</span>
                </div>
              </div>
            `,
                        showConfirmButton: false,
                        background: 'transparent',
                    });

                    const productRef = ref(db, `products/${productId}`);

                    get(productRef)
                        .then((snapshot) => {
                            if (snapshot.exists()) {
                                // Get the product data
                                const productData = snapshot.val();
                                const { images } = productData;

                                // Remove the product from the RTDB first
                                remove(productRef)
                                    .then(() => {
                                        setProducts((prevProducts) => {
                                            const updatedProducts = { ...prevProducts };
                                            delete updatedProducts[productId];
                                            return updatedProducts;
                                        });
                                        Swal.fire('Deleted', 'The product has been deleted', 'success');

                                        // Delete associated images from Firebase Storage
                                        if (Array.isArray(images)) {
                                            const deleteImagePromises = images.map((imageURL) => {
                                                const imageRef = reference(storage, imageURL);
                                                return deleteObject(imageRef);
                                            });

                                            Promise.all(deleteImagePromises)
                                                .then(() => {
                                                    console.log('Deleted associated images from Firebase Storage');
                                                })
                                                .catch((error) => {
                                                    console.error('Error deleting images from Firebase Storage:', error);
                                                });
                                        }
                                    })
                                    .catch((error) => {
                                        console.error('Error deleting product from RTDB:', error);
                                        Swal.fire('Error', 'An error occurred while deleting the product', 'error');
                                    });
                            } else {
                                console.log('Product data not found in RTDB');
                                Swal.fire('Error', 'Product data not found in the database', 'error');
                            }
                        })
                        .catch((error) => {
                            console.error('Error fetching product data from RTDB:', error);
                            Swal.fire('Error', 'An error occurred while fetching product data', 'error');
                        });
                } else {
                    console.error('Invalid product ID:', productId);
                    Swal.fire('Error', 'Invalid product ID', 'error');
                }
            }
        });
    };


    const [isViewModalOpen2, setIsViewModalOpen2] = useState(false);
    const [selectedProduct2, setSelectedProduct2] = useState(null);





    const [currentproductprice, setcurrentproductprice] = useState('')
    const showProductModal2 = (product) => {
        setcurrentproductprice(product.price)

        setSelectedProduct2(product);
        setIsViewModalOpen2(true);
    };

    const closeViewModal2 = () => {
        setIsViewModalOpen2(false);
        setSelectedProduct2(null);
    };

    const showProductModal = (product) => {
        setSelectedProduct(product);
        setIsViewModalOpen(true);
    };

    const closeViewModal = () => {
        setIsViewModalOpen(false);
        setSelectedProduct(null);
    };


    const [editedProductDetails, setEditedProductDetails] = useState({
        name: '',
        price: 0,
        measurement: '',
        rank: 0,
    });
    const [editProduct, setEditProduct] = useState(null);

    const openEditModal = (product) => {

        console.log(product)
        const dbRef = ref(db);
        get(child(dbRef, 'products/' + product))
            .then((snapshot) => {
                if (snapshot.exists()) {
                    const productData = snapshot.val();
                    console.log(productData)
                    setEditProduct(productData)
                    setEditedProductDetails({
                        name: productData.name || '', // Use empty string if 'name' is undefined
                        price: (productData.price || '').toString(), // Convert to string or use empty string
                        measurement: productData.measurement || '', // Use empty string if 'measurement' is undefined
                        rank: (productData.rank || '').toString(), // Convert to string or use empty string
                        productspecialid: (product || '').toString(),
                    });
                } else {
                    console.log('No data available');
                }
            })


    };
    const saveEditedProduct = () => {
        Swal.fire({
            html: `
        <div class="p-5" >
          <div class="spinner-border text-dark" role="status">
            <span class="visually-hidden">Loading...</span>
          </div>
        </div>
      `,
            showConfirmButton: false,
            background: 'transparent',
        });
        if (editProduct) {
            const productRef = ref(db, `products/${editedProductDetails.productspecialid}`);
            const updatedProductDetails = { ...editedProductDetails };

            // Ensure that numeric values are parsed as numbers
            updatedProductDetails.price = parseFloat(updatedProductDetails.price);
            updatedProductDetails.rank = parseInt(updatedProductDetails.rank);

            update(productRef, updatedProductDetails)
                .then(() => {
                    Swal.fire('Updated', 'The product has been updated', 'success');
                    setEditProduct(null);
                    setEditedProductDetails({
                        name: '',
                        price: '',
                        measurement: '',
                        rank: '',
                    });
                    fetchproducts();
                })
                .catch((error) => {
                    console.error('Error updating product:', error);
                    Swal.fire('Error', 'An error occurred while updating the product', 'error');
                });
        }
    };






    const [selectedSize, setSelectedSize] = useState(''); // To store the selected size
    const [customization, setCustomization] = useState(false); // To enable/disable customization
    const [customInputs, setCustomInputs] = useState({
        chest: '',
        waist: '',
        hips: '',
        inseam: '',
        shoulder: '',
    });



    const [selectedPaymentMethod, setSelectedPaymentMethod] = useState("cod");
    const [quantity, setQuantity] = useState(1);
    const [showqr, setShowQR] = useState(false);



    const [totalPrice, setTotalPrice] = useState(currentproductprice); // Initial total price is the product's price
    const handleQuantityChange = (newQuantity) => {
        if (newQuantity >= 1) {
            setQuantity(newQuantity);
            const newTotalPrice = selectedProduct2.price * newQuantity;
            setTotalPrice(newTotalPrice);
        }
    };


    useEffect(() => {
        if (selectedProduct2 && selectedPaymentMethod === "online") {
            setShowQR(true);
        } else {
            setShowQR(false);
        }
    }, [selectedProduct2, selectedPaymentMethod]);


    const addtocart = (product) => {
        Swal.fire({
            html: `
              <div class="p-5" >
                <div class="spinner-border text-danger" role="status">
                  <span class="visually-hidden">Loading...</span>
                </div>
              </div>
            `,
            showConfirmButton: false,
            background: 'transparent',
        });
        if (userData) {
            const cartRef = ref(db, `users/${userUID}/cart`);
            try {

                push(cartRef, product);

                Swal.fire({
                    icon: 'success',
                    title: 'Successfully Added to the cart',
                    showConfirmButton: true,
                    timer: 3000
                });

            } catch (error) {
                Swal.fire({
                    icon: 'error',
                    title: 'Error adding product to the cart:',
                    showConfirmButton: true,
                    timer: 3000
                });
            }
        } else {
            Swal.fire({
                icon: 'warning',
                title: 'Please Login to access cart ',
                showConfirmButton: true,
                timer: 3000
            });

        }
    };



    const billproduct = (product) => {
        const ordersRef = ref(db, 'orders/');
        const orderDetails = {
            product,
            selectedSize,
            customInputs,
            selectedPaymentMethod,
            quantity,
            totalPrice,
            userUID,
            orderstatus: "processing",
            userData
        };

        push(ordersRef, orderDetails)
            .then(() => {
                console.log('Order details saved to Firebase RTDB.');
                closeViewModal2()
                Swal.fire({
                    icon: 'success',
                    title: 'Order Placed',
                    showConfirmButton: true, confirmButtonColor: 'black',
                })
            })
            .catch((error) => {
                console.error('Error saving order details to Firebase RTDB: ', error);
                Swal.fire({
                    icon: 'error',
                    title: 'Error placing the order',
                    showConfirmButton: true, confirmButtonColor: 'black',
                })
            });
    };


    return (
        <div>
            <div className="container-fluid pb-4">
                <div className="row">
                    {Object.keys(products)
                        .sort((a, b) => products[a].rank - products[b].rank) // Sort products by rank
                        .map((productId) => {
                            const product = products[productId];
                            return (
                                <div className="col-12 col-lg-3 col-md-6" key={productId}>
                                    <div className="card mb-4">
                                        <div id={`carousel-${productId}`} className="carousel slide" data-bs-ride="carousel">
                                            <div className="carousel-inner">
                                                {product.images.map((image, imageIndex) => (
                                                    <div className={`carousel-item${imageIndex === 0 ? ' active' : ''}`} key={imageIndex}>
                                                        <img
                                                            src={image}
                                                            className=""
                                                            style={{ height: '50vh', width: '100%' }}
                                                            alt={`Product ${productId} Image ${imageIndex + 1}`}
                                                        />
                                                    </div>
                                                ))}
                                            </div>

                                        </div>
                                        <div className="card-body d-flex flex-row justify-content-between">
                                            <p className="card-text"><span className='fw-bold text-dark'></span>{product.name}</p>

                                            <p className="card-text"><span className='fw-bold text-dark'> </span> ₹{product.price}/{product.measurement}</p>
                                        </div>
                                        <div className='d-flex flex-row justify-content-between px-3 pb-2'>
                                            <button className='btn btn-dark btn sm' onClick={() => addtocart(product)}>
                                                Add to cart
                                            </button>
                                            <button className='btn btn-dark btn sm' onClick={() => showProductModal2(product)} >
                                                Buy now
                                            </button>
                                            <button className='btn btn-dark btn sm' onClick={() => showProductModal(product)} >
                                                <i className="bi bi-eye-fill"></i> View
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            );
                        })}
                </div>
            </div>


            {isViewModalOpen && selectedProduct && (
                <div className="modal" style={{ display: 'block', background: 'rgba(0, 0, 0, 0.5)', backdropFilter: 'blur(3px)' }}>
                    <div className="modal-dialog modal-lg" role="document">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title">{selectedProduct.name}</h5>
                                <button type="button" className="btn-close" aria-label="Close" onClick={closeViewModal}></button>
                            </div>

                            <div className="modal-body">
                                <div className='d-flex flex-row justify-content-between px-2'>
                                    <p>Price: ₹{selectedProduct.price} / {selectedProduct.measurement}</p>

                                </div>
                                <div className="row">
                                    {selectedProduct.images.map((image, imageIndex) => (
                                        <div key={imageIndex} className="col-12 col-lg-4">
                                            <img
                                                src={image}
                                                className="img-fluid d-lg-block d-none mb-3"
                                                style={{ height: '30vh', width: '100%' }}
                                                alt={`Product View Image ${imageIndex + 1}`}
                                            />

                                            <img
                                                src={image}
                                                className="img-fluid d-lg-none d-block mb-3"
                                                style={{ height: '50vh', width: '100%' }}
                                                alt={`Product View Image ${imageIndex + 1}`}
                                            />
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )}


            {isViewModalOpen2 && selectedProduct2 && (
                <div className="modal" style={{ display: 'block', background: 'rgba(0, 0, 0, 0.5)', backdropFilter: 'blur(3px)' }}>
                    <div className="modal-dialog modal-lg" role="document">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title">{selectedProduct2.name}</h5>
                                <button type="button" className="btn-close" aria-label="Close" onClick={closeViewModal2}></button>
                            </div>

                            <div className="modal-body">
                                <div className="d-flex flex-row justify-content-between px-2">

                                    <p><span className='fw-bold'> Product:</span> {selectedProduct2.name}</p>
                                    <p><span className='fw-bold'> Price:</span> {selectedProduct2.price}/{selectedProduct2.measurement}</p>

                                </div>
                                <div className='d-flex flex-row justify-content-around'>
                                    <div className="form-check">
                                        <input
                                            type="radio"
                                            className="form-check-input"
                                            value="S"
                                            checked={selectedSize === 'S'}
                                            onChange={() => {
                                                setSelectedSize('S')
                                                setCustomization('')
                                            }}
                                        />
                                        <label className="form-check-label">S</label>
                                    </div>
                                    <div className="form-check">
                                        <input
                                            type="radio"
                                            className="form-check-input"
                                            value="M"
                                            checked={selectedSize === 'M'}
                                            onChange={() => { setSelectedSize('M') }}
                                        />
                                        <label className="form-check-label">M</label>
                                    </div>
                                    <div className="form-check">
                                        <input
                                            type="radio"
                                            className="form-check-input"
                                            value="L"
                                            checked={selectedSize === 'L'}
                                            onChange={() => {
                                                setSelectedSize('L')
                                                setCustomization('')
                                            }}
                                        />
                                        <label className="form-check-label">L</label>
                                    </div>
                                    <div className="form-check">
                                        <input
                                            type="radio"
                                            className="form-check-input"
                                            value="XL"
                                            checked={selectedSize === 'XL'}
                                            onChange={() => {
                                                setSelectedSize('XL')
                                                setCustomization('')
                                            }}
                                        />
                                        <label className="form-check-label">XL</label>
                                    </div>
                                    <div className="form-check">
                                        <input
                                            type="radio"
                                            className="form-check-input"
                                            value="XXL"
                                            checked={selectedSize === 'XXL'}
                                            onChange={() => {
                                                setSelectedSize('XXL')
                                                setCustomization('')
                                            }}
                                        />
                                        <label className="form-check-label">XXL</label>
                                    </div>

                                    <div className="form-check">
                                        <input
                                            type="radio"
                                            className="form-check-input"
                                            value="custom"
                                            checked={customization}
                                            onChange={() => {
                                                setSelectedSize(''); // Uncheck other size options
                                                setCustomization(!customization);
                                            }}
                                        />
                                        <label className="form-check-label">Customize</label>
                                    </div>
                                </div>
                                <div>

                                </div>
                                {customization && (
                                    <div>
                                        <p className='mt-4'>Customize your size with centimetres </p>
                                        <div className="row">
                                            <div className="col-md-4 mb-2">
                                                {/* Custom Input 1 */}
                                                <div className="form-group">
                                                    <label>Chest:</label>
                                                    <input
                                                        type="text"
                                                        className="form-control"
                                                        value={customInputs.input1}
                                                        onChange={(e) => setCustomInputs({ ...customInputs, chest: e.target.value })}
                                                    />
                                                </div>
                                            </div>
                                            <div className="col-md-4 mb-2">
                                                {/* Custom Input 2 */}
                                                <div className="form-group">
                                                    <label>Waist:</label>
                                                    <input
                                                        type="text"
                                                        className="form-control"
                                                        value={customInputs.input2}
                                                        onChange={(e) => setCustomInputs({ ...customInputs, waist: e.target.value })}
                                                    />
                                                </div>
                                            </div>
                                            <div className="col-md-4  mb-2">
                                                {/* Custom Input 3 */}
                                                <div className="form-group">
                                                    <label>Hips:</label>
                                                    <input
                                                        type="text"
                                                        className="form-control"
                                                        value={customInputs.input3}
                                                        onChange={(e) => setCustomInputs({ ...customInputs, hips: e.target.value })}
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                        <div className="row">
                                            <div className="col-md-6  mb-2">
                                                <div className="form-group">
                                                    <label>Inseam:</label>
                                                    <input
                                                        type="text"
                                                        className="form-control"
                                                        value={customInputs.input3}
                                                        onChange={(e) => setCustomInputs({ ...customInputs, inseam: e.target.value })}
                                                    />
                                                </div>
                                            </div>
                                            <div className="col-md-6  mb-2">
                                                <div className="form-group">
                                                    <label>Shoulder:</label>
                                                    <input
                                                        type="text"
                                                        className="form-control"
                                                        value={customInputs.input3}
                                                        onChange={(e) => setCustomInputs({ ...customInputs, shoulder: e.target.value })}
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                )}
                                <div>


                                    <div className="form-group mb-4">
                                        <label htmlFor="quantityInput" className="fw-bold ps-1 mb-2 text-dark">Quantity:</label>
                                        <div className="input-group">
                                            <span className="input-group-btn">
                                                <button
                                                    type="button"
                                                    className="btn btn-dark"
                                                    onClick={() => handleQuantityChange(quantity - 1)}
                                                >
                                                    -
                                                </button>
                                            </span>
                                            <input
                                                type="number"
                                                className="form-control text-center"
                                                id="quantityInput"
                                                value={quantity}
                                                onChange={(e) => handleQuantityChange(parseInt(e.target.value, 10))}
                                            />
                                            <span className="input-group-btn">
                                                <button
                                                    type="button"
                                                    className="btn btn-dark"
                                                    onClick={() => handleQuantityChange(quantity + 1)}
                                                >
                                                    +
                                                </button>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div className='d-flex my-2 text-center'>
                                    <h6 className='fw-bold'>Total Price:   {totalPrice}</h6>


                                </div>

                                {showqr && (
                                    <div className='mb-3'>
                                        <img src={qrcode} className='img-fluid' />
                                    </div>
                                )}
                                <div className="form-group mb-3">
                                    <label htmlFor="paymentMethodDropdown" className="fw-bold ps-1 mb-2 text-dark">Payment Method:</label>
                                    <select
                                        className="form-control"
                                        id="paymentMethodDropdown"
                                        value={selectedPaymentMethod}
                                        onChange={(e) => setSelectedPaymentMethod(e.target.value)}
                                    >
                                        <option value="cod">Cash on Delivery (COD)</option>
                                        <option value="online">Online Payment</option>
                                    </select>
                                </div>
                                <button
                                    className="btn btn-dark btn-lg w-100"
                                    onClick={() => billproduct(selectedProduct2)}
                                >
                                    Buy Now
                                </button>


                            </div>
                        </div>
                    </div>
                </div>
            )}




        </div>
    );
};

export default Products;
