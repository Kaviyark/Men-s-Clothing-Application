import { child, get, ref, set } from 'firebase/database';
import React, { useEffect, useState } from 'react';
import Swal from 'sweetalert2';
import { db } from '../firebase';

const Orders = ({ userUID }) => {
    const [products, setProducts] = useState({});

    const handleCancelOrder = (productId) => {
        // Make the API call to update the order status in Firebase
        // Assuming you have a path like 'orders/{orderId}/orderstatus' to update the status
        const dbRef = ref(db);
        const orderRef = child(dbRef, `orders/${productId}/orderstatus`);

        set(orderRef, 'Cancelled')
            .then(() => {
                // Success, the order status has been updated to "Cancelled"
                // You can also update the state to reflect the change
                setProducts((prevProducts) => ({
                    ...prevProducts,
                    [productId]: {
                        ...prevProducts[productId],
                        orderstatus: 'Cancelled',
                    },
                }));
            })
            .catch((error) => {
                console.error('Error updating order status:', error);
                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: 'An error occurred while cancelling the order',
                });
            });
    };

    useEffect(() => {
        const dbRef = ref(db);

        get(child(dbRef, 'orders/'))
            .then((snapshot) => {
                if (snapshot.exists()) {
                    const ordersData = snapshot.val();

                    const userOrders = {};
                    for (const orderId in ordersData) {
                        if (ordersData[orderId].userUID === userUID) {
                            userOrders[orderId] = ordersData[orderId];
                        }
                    }
                    setProducts(userOrders);
                } else {
                    console.log('No data available');
                }
            })
            .catch((error) => {
                console.error(error);
            });
    }, [userUID]);

    return (
        <div>
            <div className='d-flex flex-column justify-content-between'>
                <div className='pt-4'>
                    {Object.keys(products).length === 0 ? (
                        <p className="text-center">No orders available.</p>
                    ) : (
                        <div className="container-fluid pb-4">
                            <div className="row">
                                {Object.keys(products)
                                    .sort((a, b) => products[a].rank - products[b].rank)
                                    .map((productId) => {
                                        const product = products[productId];
                                        const productImages = product.product.images || [];

                                        // Select the first image (if available) from the images array
                                        const firstImage = productImages.length > 0 ? productImages[0] : null;

                                        return (
                                            <div className="col-12 col-lg-3 col-md-6" key={productId}>
                                                <div className="card mb-4">
                                                    <div id={`carousel-${productId}`} className="carousel slide" data-bs-ride="carousel">
                                                        {firstImage && (
                                                            <div className="carousel-item active">
                                                                <img
                                                                    src={firstImage}
                                                                    className=""
                                                                    style={{ height: '40vh', width: '100%' }}
                                                                    alt={`Product ${productId} Image 1`}
                                                                />
                                                            </div>
                                                        )}
                                                    </div>
                                                    <div className="card-body text-start">
                                                        <p className="card-text"><span className='fw-bold text-danger'>Order ID: </span>{productId}</p>
                                                        <p className="card-text"><span className='fw-bold text-danger'>Price: </span> ₹{product.totalPrice}</p>
                                                        <p className="card-text"><span className='fw-bold text-danger'>Order Status: </span>{product.orderstatus}</p>
                                                        <p className="card-text"><span className='fw-bold text-danger'>Quantity: </span> {product.quantity}</p>
                                                        {product.orderstatus !== 'Cancelled' && (
                                                            <button className='btn btn-danger' onClick={() => handleCancelOrder(productId)}>Cancel</button>
                                                        )}
                                                    </div>
                                                </div>
                                            </div>
                                        );
                                    })}
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}

export default Orders;
