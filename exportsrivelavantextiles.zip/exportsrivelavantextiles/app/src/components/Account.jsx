import React, { useState, useEffect } from 'react';
import { EmailAuthProvider, deleteUser, onAuthStateChanged, reauthenticateWithCredential, sendPasswordResetEmail } from 'firebase/auth';
import { ref, onValue, set, remove } from 'firebase/database';
import { auth, db } from '../firebase';
import Swal from 'sweetalert2';

const Account = () => {
    const [userDetails, setUserDetails] = useState({
        name: '',
        phone: '',
    });

    const [isEditing, setIsEditing] = useState(false);

    const handleDeleteAccount = () => {
        const user = auth.currentUser;
        if (user) {
            // Show a reauthentication prompt
            Swal.fire({
                title: 'Reauthentication Required',
                text: 'To delete your account, please reauthenticate by entering your current password.',
                input: 'password', // Input field for the user's current password
                inputAttributes: {
                    autocapitalize: 'off',
                    autocorrect: 'off',
                },
                showCancelButton: true,
                confirmButtonText: 'Delete',
                confirmButtonColor: 'black',
                cancelButtonText: 'Cancel',
                cancelButtonColor: 'red',
                inputValidator: (value) => {
                    if (!value) {
                        return 'Password is required';
                    }
                },
            }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire({
                        html: `
                          <div className="p-5" >
                            <div className="spinner-border text-dark" role="status">
                              <span className="visually-hidden">Loading...</span>
                            </div>
                          </div>
                        `,
                        showConfirmButton: false,
                        background: 'transparent',
                    });
                    const credential = EmailAuthProvider.credential(user.email, result.value);
                    reauthenticateWithCredential(user, credential)
                        .then(() => {

                            deleteUser(user)
                                .then(async () => {
                                    Swal.fire({
                                        icon: 'success',
                                        title: 'Account Deletion Successfull',
                                        showConfirmButton: true,
                                        confirmButtonColor: 'black',
                                        timer: 3000
                                    })
                                    const uid = user.uid;
                                    const userRef = ref(db, 'users/' + uid);

                                    await remove(userRef);
                                    window.location.reload();
                                })
                                .catch((error) => {
                                    Swal.fire({
                                        icon: 'error',
                                        title: 'Error Deleting Account',
                                        showConfirmButton: true,
                                        confirmButtonColor: 'black',
                                        timer: 3000
                                    })
                                });
                        })
                        .catch((reauthError) => {
                            Swal.fire({
                                icon: 'error',
                                title: 'Reauthentication failed:',
                                showConfirmButton: true,
                                confirmButtonColor: 'black',
                                timer: 3000
                            })
                            console.error('Reauthentication failed:', reauthError);
                        });
                }
            });
        }
    };


    const handleResetPassword = () => {
        const user = auth.currentUser;
        if (user) {
            // Show a password reset prompt
            Swal.fire({
                title: 'Reset Password',
                text: 'To reset your password, please enter your email address.',
                input: 'email', // Input field for the user's email
                inputAttributes: {
                    autocapitalize: 'none',
                    autocorrect: 'off',
                },
                showCancelButton: true,
                confirmButtonText: 'Reset Password',
                confirmButtonColor: 'black',
                cancelButtonText: 'Cancel',
                cancelButtonColor: 'red',
                inputValidator: (value) => {
                    if (!value) {
                        return 'Email address is required';
                    }
                },
            }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire({
                        html: `
                          <div className="p-5" >
                            <div className="spinner-border text-dark" role="status">
                              <span className="visually-hidden">Loading...</span>
                            </div>
                          </div>
                        `,
                        showConfirmButton: false,
                        background: 'transparent',
                    });
                    const emailAddress = result.value;
                    sendPasswordResetEmail(auth, emailAddress)
                        .then(() => {
                            Swal.fire({
                                icon: 'success',
                                title: 'Password Reset Email Sent',
                                text: `An email with instructions to reset your password has been sent to ${emailAddress}.`,
                                timer: 3000,
                            });
                        })
                        .catch((error) => {
                            console.error('Error sending password reset email:', error);
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: 'An error occurred while sending the password reset email. Please try again.',
                            });
                        });
                }
            });
        }
    };


    useEffect(() => {
        onAuthStateChanged(auth, (user) => {
            if (user) {
                const uid = user.uid;
                const userinforef = ref(db, 'users/' + uid + '/profiledetails');
                onValue(userinforef, (snapshot) => {
                    const data = snapshot.val();
                    setUserDetails(data || { name: '', phone: '' });
                });
            } else {
                setUserDetails({ name: '', phone: '' });
            }
        });
    }, []);

    const handleEditClick = () => {
        setIsEditing(true);
    };


    const handleSaveClick = () => {
        Swal.fire({
            html: `
              <div className="p-5" >
                <div className="spinner-border text-dark" role="status">
                  <span className="visually-hidden">Loading...</span>
                </div>
              </div>
            `,
            showConfirmButton: false,
            background: 'transparent',
        });
        const user = auth.currentUser;
        if (user) {
            const uid = user.uid;
            const userinforef = ref(db, 'users/' + uid + '/profiledetails');
            set(userinforef, userDetails); // Update the data in the database
            Swal.fire({
                icon: 'success',
                title: 'Profile Updated Successfully',
                showConfirmButton: true,
                confirmButtonColor: 'black',
                timer: 3000
            })
        }
        setIsEditing(false);
    };

    const handleCancelClick = () => {
        setIsEditing(false);

    };

    return (
        <div className=' mt-2 container-fluid border rounded-3 p-3'>


            {isEditing ? (
                <div>
                    <div className='d-flex flex-row justify-content-between mb-3'>
                        <h5 className='animate__animated animate__fadeIn text-uppercase'>Edit Profile</h5>
                        <div className='d-flex'>
                            <div>
                                <button onClick={handleSaveClick} className=' btn btn-dark btn-sm me-3'>Save</button>
                            </div>

                            <div>
                                <button onClick={handleCancelClick} className=' btn btn-danger btn-sm'>Cancel</button>
                            </div>

                        </div>
                    </div>
                    <label className='fw-bold animate__animated animate__fadeIn text-uppercase'>Name:</label>
                    <input
                        type="text"
                        value={userDetails.name}
                        onChange={(e) => setUserDetails({ ...userDetails, name: e.target.value })}
                        className='animate__animated animate__fadeIn form-control'
                    />
                    <br />
                    <label className='fw-bold animate__fadeIn text-uppercase'>Phone:</label>
                    <input
                        type="text"
                        value={userDetails.phone}
                        onChange={(e) => setUserDetails({ ...userDetails, phone: e.target.value })}
                        className='animate__animated animate__fadeIn form-control'
                    />
                    <br />
                </div>
            ) : (
                <div>
                    <div className='d-flex flex-row justify-content-between mb-3'>
                        <h5 className='animate__animated animate__fadeIn text-uppercase'>Profile</h5>
                        <div>
                            <button onClick={handleEditClick} className='animate__animated animate__fadeIn btn btn-dark btn-sm text-uppercase'>Edit</button>
                        </div>
                    </div>

                    <p className='animate__animated animate__fadeIn'><span className=' fw-bold text-uppercase'>Name:
                    </span>  &nbsp; <br />{userDetails.name}</p>
                    <p className='animate__animated animate__fadeIn'><span className=' fw-bold text-uppercase'>Phone:
                    </span> <br /> {userDetails.phone}</p>

                </div>
            )}
            <div className='d-flex flex-row justify-content-between pt-3'>
                <div>
                    <button onClick={handleDeleteAccount} className='animate__animated animate__fadeIn btn btn-danger btn-sm text-uppercase'>Delete Account</button>
                </div>
                <div>
                    <button onClick={handleResetPassword} className='animate__animated animate__fadeIn btn btn-dark btn-sm text-uppercase'>Change Password</button>
                </div>
            </div>
        </div>
    );
};

export default Account;
