import React, { useEffect, useRef, useState } from 'react'

import { auth } from '../firebase'
import Swal from 'sweetalert2'
import Cart from './Cart'

const Navbar = ({ SetLoginPage, SetAccountPage, userData, SetOrdersPage, trigger, SetLoginPageReg,userUID }) => {

    const [username, setusername] = useState('')
    const [navbaranimate, setnavbaranimate] = useState(false)
    const [navbarcontentanimate, setnavbarcontentanimate] = useState(false)


    console.log(userUID)
    const [loginstate, setloginstate] = useState(false)

    useEffect(() => {
        if (userData) {
            setloginstate(true)
            setusername(userData.name);
        }
        animatenavbarcontent();
    }, [userData]);


    const animatenavbar = () => {
        setnavbaranimate(true);
        setTimeout(() => {
            setnavbaranimate(false);
        }, 1000);
    };





    const animatenavbarcontent = () => {
        setnavbarcontentanimate(true);

        setTimeout(() => {
            setnavbarcontentanimate(false);
        }, 1000);
    };

    const handleOffcanvasHidden = () => {
        animatenavbarcontent()
    }
    useEffect(() => {
        const navbarOffcanvas = document.getElementById('offcanvasDarkNavbar');
        if (navbarOffcanvas) {
            navbarOffcanvas.addEventListener('hidden.bs.offcanvas', handleOffcanvasHidden);
        }
        const navbarOffcanvas2 = document.getElementById('offcanvasDarkCart');
        if (navbarOffcanvas2) {
            navbarOffcanvas2.addEventListener('hidden.bs.offcanvas', handleOffcanvasHidden);
        }
    }, []);



    const logout = async () => {
        Swal.fire({
            html: `
              <div className="p-5" >
                <div className="spinner-border text-dark" role="status">
                  <span className="visually-hidden">Loading...</span>
                </div>
              </div>
            `,

            showConfirmButton: false,
            background: 'transparent',
        });
        try {
            await auth.signOut();
            setloginstate(false)
            Swal.fire({
                icon: 'success',
                title: 'Logout Successful',
                showConfirmButton: true, confirmButtonColor: 'black',
                timer: 3000
            })
        } catch (error) {

        }
    }




    useEffect(() => {
        if (trigger) {
            animatenavbarcontent();
            console.log(true)
        }
    }, [trigger]);

    return (
        <div className=' fixed-top'>
            <nav className="navbar navbar-dark text-bg-navbar">
                <div className="container-fluid  px-lg-4  pt-2">
                    <h3 className={`x ${navbarcontentanimate
                        ? 'animate__animated animate__slideInLeft'
                        : ' '
                        }`}>
                        <span className="bi bi-text-left " onClick={animatenavbar} data-bs-toggle="offcanvas" data-bs-target="#offcanvasDarkNavbar" aria-controls="offcanvasDarkNavbar" aria-label="Toggle navigation"></span>
                    </h3>
                    <div className='d-flex flex-column'>
                        <h4 className={`text-uppercase text-center title-card  ${navbarcontentanimate
                            ? ' animate__animated animate__fadeInDown'
                            : ' '
                            }`} >Sri Velavan Textiles</h4>

                    </div>

                    <h3 className={`x ${navbarcontentanimate
                        ? 'animate__animated animate__slideInRight'
                        : ' '
                        }`}>
                        <span className="bi bi-cart-fill" onClick={animatenavbar} data-bs-toggle="offcanvas" data-bs-target="#offcanvasDarkCart" aria-controls="offcanvasDarkCart" aria-label="Toggle navigation"></span>
                    </h3>


                    <div className="offcanvas offcanvas-start text-bg-navbar w-100 max-width-navbar" id="offcanvasDarkNavbar" aria-labelledby="offcanvasDarkNavbarLabel">
                        <div className="offcanvas-header ">
                            <h1 className={`offcanvas-title ${navbaranimate ? 'animate__animated animate__fadeInDown' : ''
                                }`} id="offcanvasDarkNavbarLabel"></h1>
                            <h3 onClick={animatenavbarcontent} className={`text-dark pt-2 ${navbaranimate ? 'animate__animated animate__fadeInUp' : ''
                                }`} data-bs-dismiss="offcanvas" aria-label="Close"><i className="bi bi-x-lg"></i></h3>
                        </div>
                        <div className="offcanvas-body">
                            <div className=''>
                                <div className={`text-uppercase px-3 py-3 display-6 ${navbaranimate ? 'animate__animated animate__fadeInUp ' : ''
                                    }`}>
                                    {loginstate && (<div>
                                        Hi  {username ? (username.length > 15 ? username.slice(0, 15) + '...' : username) : ""}</div>)}
                                </div>


                                {!loginstate && (<div>   <div data-bs-dismiss="offcanvas" onClick={SetLoginPage} className={`hoverblack px-3 py-3 rounded-3 display-6 ${navbaranimate ? 'animate__animated animate__fadeInUp ' : ''
                                    }`}>
                                    LOGIN
                                </div>
                                </div>)}




                                {loginstate && (<div>
                                    <div data-bs-dismiss="offcanvas" onClick={SetAccountPage} className={`hoverblack px-3 py-3 rounded-3 display-6 ${navbaranimate ? 'animate__animated animate__fadeInUp ' : ''
                                        }`} >
                                        ACCOUNT
                                    </div>
                                </div>)}


                                {loginstate && (<div>
                                    <div data-bs-dismiss="offcanvas" onClick={SetOrdersPage} className={`hoverblack px-3 py-3 rounded-3 display-6 ${navbaranimate ? 'animate__animated animate__fadeInUp ' : ''
                                        }`} >
                                        ORDERS     </div></div>)}

                                {loginstate && (<div>
                                    <div className={`hoverblack px-3 py-3 rounded-3 display-6 ${navbaranimate ? 'animate__animated animate__fadeInUp ' : ''
                                        }`} onClick={logout}>

                                        LOGOUT
                                    </div>
                                </div>)}
                            </div>
                        </div>
                    </div>

                    <div className="offcanvas offcanvas-end text-bg-navbar w-100 max-width-navbar" id="offcanvasDarkCart" aria-labelledby="offcanvasDarkNavbarLabel">
                        <div className="offcanvas-header ">
                            <h1 className={`offcanvas-title ${navbaranimate ? 'animate__animated animate__fadeInUp' : ''
                                }`} id="offcanvasDarkNavbarLabel">CART</h1>
                            <h3 onClick={animatenavbarcontent} className={`text-dark pt-2 ${navbaranimate ? 'animate__animated animate__fadeInDown' : ''
                                }`} data-bs-dismiss="offcanvas" aria-label="Close"><i className="bi bi-x-lg"></i></h3>
                        </div>
                        <div className="offcanvas-body">
                            <div className=''>
                                <Cart userData={userData} userUID={userUID} />
                            </div>
                        </div>
                    </div>

                </div>
            </nav >
        

        </div >
    )
}

export default Navbar