import React, { useEffect, useState } from 'react'
import Navbar from './components/Navbar'
import Products from './components/Products'
import Auth from './components/auth/Auth'
import { auth, db } from './firebase'
import { onAuthStateChanged } from 'firebase/auth'
import { onValue, ref } from 'firebase/database'
import Account from './components/Account'
import Orders from './components/Orders'
import Swal from 'sweetalert2'

const Engine = () => {

    const [trigger, setTrigger] = useState(0);


    const [loginpage, setloginpage] = useState(false)
    const [accountpage, setaccountpage] = useState(false)
    const [orderspage, setorderspage] = useState(false)

    const [authpage, setauthpage] = useState(false)
    const [loggedindetails, setloggedindetails] = useState(null)
    const [loggedinuid, setloggedinuid] = useState(null)



    const animateauthpage = () => {
        setauthpage(true);
        setTimeout(() => {
            setauthpage(false);
        }, 1000);
    };

    const animatechildcomponent = () => {
        setTrigger((trigger) => trigger + 1);
    }

    const SetLoginPage = () => {
        setloginpage(!loginpage)
        animatechildcomponent()

    }

    const SetAccountPage = () => {
        setaccountpage(!accountpage)
        animatechildcomponent()
    }

    const SetOrdersPage = () => {
        setorderspage(!orderspage)
        animatechildcomponent()
    }



    useEffect(() => {
        onAuthStateChanged(auth, (user) => {
            if (user) {
                const uid = user.uid;
                setloggedinuid(uid)
                console.log(uid)
                const userinforef = ref(db, 'users/' + uid + '/profiledetails');
                onValue(userinforef, (snapshot) => {
                    const data = snapshot.val();

                    if (data.role === "user") {
                        setloggedindetails(data)

                    }
                    else {
                        auth.signOut();
                        window.location.reload()
                    }
                });
            } else {
                setloggedindetails(null)
                auth.signOut();

            }
        });
    }, []);












    return (
        <div>
            <div className=''>
                <Navbar SetLoginPage={SetLoginPage} userData={loggedindetails} userUID={loggedinuid} SetAccountPage={SetAccountPage} SetOrdersPage={SetOrdersPage} trigger={trigger} />

                <div className=' container-fluid' style={{ marginTop: "100px" }}>
                    <div>
                        <Products userData={loggedindetails} userUID={loggedinuid} />
                    </div>
                </div>

            </div>


            {loginpage && (
                <div className=''>
                    <div
                        className={`modal d-block  border-0 ${authpage
                            ? 'animate__animated animate__zoomIn animate__faster'
                            : ''
                            }`}
                        tabIndex="-1"
                        role="dialog"
                        style={{
                            display: 'block',
                            background: 'rgba(0, 0, 0, 0.5)',
                            backdropFilter: 'blur(3px)',
                        }}
                    >
                        <div className="modal-dialog modal-fullscreen  border-0">
                            <div className="modal-content text-bg-green border-0 rounded-0" >

                                <div className="modal-body d-flex flex-column justify-content-between">
                                    <div className='d-flex flex-row justify-content-between'>
                                        <h5 onClick={SetLoginPage}></h5>

                                        <h5 className='animate__animated animate__zoomIn' onClick={SetLoginPage}><i className="bi bi-x-lg"></i></h5>
                                    </div>
                                    <div>
                                        <Auth SetLoginPage={SetLoginPage} />
                                    </div>
                                    <div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )
            }



            {accountpage && (
                <div className=''>
                    <div
                        className={`modal d-block  border-0 ${authpage
                            ? 'animate__animated animate__zoomIn animate__faster'
                            : ''
                            }`}
                        tabIndex="-1"
                        role="dialog"
                        style={{
                            display: 'block',
                            background: 'rgba(0, 0, 0, 0.5)',
                            backdropFilter: 'blur(3px)',
                        }}
                    >
                        <div className="modal-dialog modal-fullscreen  border-0">
                            <div className="modal-content text-bg-green border-0 rounded-0" >

                                <div className="modal-body">
                                    <div className='d-flex flex-row justify-content-between '>
                                        <h5 onClick={SetAccountPage} className='animate__animated animate__fadeInDown display-4'>Account</h5>
                                        <h5 className='animate__animated animate__fadeInUp' onClick={SetAccountPage}><i className="bi bi-x-lg"></i></h5>
                                    </div>
                                    <div>
                                        <Account />
                                    </div>
                                    <div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )
            }


            {orderspage && (
                <div className=''>
                    <div
                        className={`modal d-block  border-0 ${authpage
                            ? 'animate__animated animate__zoomIn animate__faster'
                            : ''
                            }`}
                        tabIndex="-1"
                        role="dialog"
                        style={{
                            display: 'block',
                            background: 'rgba(0, 0, 0, 0.5)',
                            backdropFilter: 'blur(3px)',
                        }}
                    >
                        <div className="modal-dialog modal-fullscreen  border-0">
                            <div className="modal-content text-bg-green border-0 rounded-0" >

                                <div className="modal-body">
                                    <div className='d-flex flex-row justify-content-between'>
                                        <h5 onClick={SetOrdersPage} className='animate__animated animate__fadeInUp display-4'>Orders</h5>

                                        <h5 className='animate__animated animate__fadeInDown' onClick={SetOrdersPage}><i className="bi bi-x-lg"></i></h5>
                                    </div>
                                    <div>
                                        <Orders userUID={loggedinuid} />
                                    </div>
                                    <div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )
            }


        </div >
    )
}

export default Engine