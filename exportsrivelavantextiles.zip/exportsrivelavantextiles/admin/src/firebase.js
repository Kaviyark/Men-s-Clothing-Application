import { initializeApp } from "firebase/app";
import { getDatabase } from "firebase/database";
import { getAuth } from "firebase/auth";
import { getStorage } from "firebase/storage"


const firebaseConfig = {
    apiKey: "AIzaSyCjoPOx9MnEmtYZ9DjoKY4Vpo-3cOT-ijs",
    authDomain: "sri-velavan-textiles.firebaseapp.com",
    databaseURL: "https://sri-velavan-textiles-default-rtdb.firebaseio.com",
    projectId: "sri-velavan-textiles",
    storageBucket: "sri-velavan-textiles.appspot.com",
    messagingSenderId: "277784995645",
    appId: "1:277784995645:web:be14a6e23f99cfcc1bc754",
    measurementId: "G-DEGPKDDJW0"
};


const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getDatabase(app);
const storage = getStorage(app);

export { app, db, auth, storage }
