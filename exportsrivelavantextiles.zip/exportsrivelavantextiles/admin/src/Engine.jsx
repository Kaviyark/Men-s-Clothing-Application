import React, { useEffect, useState } from 'react'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import { auth, db } from './firebase'
import { onAuthStateChanged } from 'firebase/auth';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import { onValue, ref } from 'firebase/database';
import Swal from 'sweetalert2';
const Engine = () => {
    const [user, setuser] = useState(false)

    useEffect(() => {
        onAuthStateChanged(auth, (user) => {
            Swal.fire({
                html: `
                  <div class="p-5">
                    <div class="spinner-border text-dark" role="status">
                      <span class="visually-hidden">Loading...</span>
                    </div>
                  </div>
                `,
                timer: 2000, // Set the timer to 2000 milliseconds (2 seconds)
                showConfirmButton: false,
                background: 'transparent',

            });

            if (user) {

                const uid = user.uid;

                const userinforef = ref(db, 'users/' + uid + '/profiledetails');
                onValue(userinforef, (snapshot) => {
                    const data = snapshot.val();

                    if (data.role === "admin") {
                        setuser(true)
                    }
                    else {
                        auth.signOut();
                    }
                });
            } else {
                setuser(false)

            }
        });
    }, []);
    return (
        <div>
            <Router>
                <Routes>
                    <Route path="/login" element={user ? <Navigate to="/dashboard" /> : <Login />} />
                    <Route path="/dashboard" element={user ? <Dashboard /> : <Navigate to="/login" />} />
                    <Route index element={<Navigate to="/dashboard" />} />
                </Routes>
            </Router></div>
    )
}

export default Engine