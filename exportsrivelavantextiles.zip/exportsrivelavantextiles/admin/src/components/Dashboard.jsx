import React, { useState } from 'react'
import Products from '../pages/Products';
import Users from '../pages/Users';
import Admins from '../pages/Admins';
import Orders from '../pages/Orders';
import Swal from 'sweetalert2';
import { auth } from '../firebase';
import Account from '../pages/Account';
import DeliveredOrders from '../pages/DeliveredOrders';

const Dashboard = () => {
  const [activeComponent, setActiveComponent] = useState("Products");

  const renderActiveComponent = () => {
    switch (activeComponent) {
      case "Products":
        return <Products />;
      case "Users":
        return <Users />;
      case "Admins":
        return <Admins />;
      case "Orders":
        return <Orders />;
      case "Account":
        return <Account />;
      case "DeliveredOrders":
        return <DeliveredOrders />;
    }

  };



  const logout = async () => {
    Swal.fire({
      html: `
          <div className="p-5" >
            <div className="spinner-border text-dark" role="status">
              <span className="visually-hidden">Loading...</span>
            </div>
          </div>
        `,

      showConfirmButton: false,
      background: 'transparent',
    });
    try {
      await auth.signOut();

      Swal.fire({
        icon: 'success',
        title: 'Logout Successful',
        showConfirmButton: true, confirmButtonColor: 'black',
        timer: 3000
      })
    } catch (error) {

    }
  }
  return (
    <div>
      <div className=''>
        <div className="container-fluid">
          <div className="row">
            {/* Left Sidebar */}
            <div className="col-2 border-end position-fixed text-bg-green rounded-end-4 d-lg-block d-none">
              <div className="d-flex flex-column justify-content-between vh-100 py-4">
                <div><h6 className='fw-bold ps-3 text-uppercase'>Sri Velavan Textile</h6></div>
                <div className='' style={{ height: "80vh" }}>
                  <div className={`p-2 ps-3 rounded-3 my-2  ${activeComponent === "Products" ? " text-bg-dark " : ""}`}
                    onClick={() => setActiveComponent("Products")}>
                    Products
                  </div>
                  <div className={`p-2 ps-3 rounded-3 my-2  ${activeComponent === "Orders" ? " text-bg-dark " : ""}`}
                    onClick={() => setActiveComponent("Orders")}>
                    Orders
                  </div>
                  <div className={`p-2 ps-3 rounded-3 my-2  ${activeComponent === "Users" ? " text-bg-dark " : ""}`}
                    onClick={() => setActiveComponent("Users")}>
                    Users
                  </div>
                  <div className={`p-2 ps-3 rounded-3 my-2  ${activeComponent === "Admins" ? " text-bg-dark " : ""}`}
                    onClick={() => setActiveComponent("Admins")}>
                    Admins
                  </div>
                  <div className={`p-2 ps-3 rounded-3 my-2  ${activeComponent === "DeliveredOrders" ? " text-bg-dark " : ""}`}
                    onClick={() => setActiveComponent("DeliveredOrders")}>
                    Delivered Orders
                  </div>
                  <div className={`p-2 ps-3 rounded-3 my-2  ${activeComponent === "Account" ? " text-bg-dark " : ""}`}
                    onClick={() => setActiveComponent("Account")}>
                    My Profile
                  </div>
                  <div>

                  </div>
                </div>

                <div>

                </div>
                <div>
                  <button className="btn btn-dark" onClick={logout}>Logout</button>
                </div>
              </div>
            </div>


            <div className="col-lg-10 col-12 offset-lg-2 pt-4 mt-lg-0 mt-5">
              <div className="content ps-1">
                {renderActiveComponent()}
              </div>
            </div>


          </div>
        </div>
      </div>

      <div className='d-lg-none d-block'>
        <div className='d-flex flex-row justify-content-between fixed-top px-3 pt-3 bg-white '>
          <h5 className="offcanvas-title fw-bold text-uppercase" id="offcanvasNavbarLabel">Sri Velavan Textile</h5>

          <h1 data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
            <i className='bi bi-list-nested '></i>
          </h1>
        </div>
      </div>



      <div className='d-lg-none d-block'>
        <nav className="navbar bg-body-tertiary fixed-bottom w-100">


          <div className="container-fluid">
            <div className="offcanvas offcanvas-end" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">

              <div className="offcanvas-body d-flex flex-column justify-content-between" style={{ height: "90vh" }}>


                <div className='' >
                  <div className="d-flex flex-row justify-content-between">
                    <h3 className="offcanvas-title fw-bold" id="offcanvasNavbarLabel">ADMIN TOOLS</h3>
                    <h1 type="button" className="bi bi-x-lg" data-bs-dismiss="offcanvas" aria-label="Close"></h1>
                  </div>
                  <div data-bs-dismiss="offcanvas" className={`p-2 ps-3 rounded-3 my-2  ${activeComponent === "Products" ? " text-bg-dark " : ""}`}
                    onClick={() => setActiveComponent("Products")}>
                    Products
                  </div>
                  <div data-bs-dismiss="offcanvas" className={`p-2 ps-3 rounded-3 my-2  ${activeComponent === "Orders" ? " text-bg-dark " : ""}`}
                    onClick={() => setActiveComponent("Orders")}>
                    Orders
                  </div>
                  <div data-bs-dismiss="offcanvas" className={`p-2 ps-3 rounded-3 my-2  ${activeComponent === "Users" ? " text-bg-dark " : ""}`}
                    onClick={() => setActiveComponent("Users")}>
                    Users
                  </div>
                  <div data-bs-dismiss="offcanvas" className={`p-2 ps-3 rounded-3 my-2  ${activeComponent === "Admins" ? " text-bg-dark " : ""}`}
                    onClick={() => setActiveComponent("Admins")}>
                    Admins
                  </div>
                  <div data-bs-dismiss="offcanvas" className={`p-2 ps-3 rounded-3 my-2  ${activeComponent === "DeliveredOrders" ? " text-bg-dark " : ""}`}
                    onClick={() => setActiveComponent("DeliveredOrders")}>
                    Delivered Orders
                  </div>
                  <div data-bs-dismiss="offcanvas" className={`p-2 ps-3 rounded-3 my-2  ${activeComponent === "Account" ? " text-bg-dark " : ""}`}
                    onClick={() => setActiveComponent("Account")}>
                    My Profile
                  </div>
                </div>
                <div data-bs-dismiss="offcanvas" className='text-end'>
                  <button className="btn btn-dark" onClick={logout}>Logout</button>
                </div>
              </div>



            </div>
          </div>
        </nav>
      </div >


    </div >
  )
}

export default Dashboard