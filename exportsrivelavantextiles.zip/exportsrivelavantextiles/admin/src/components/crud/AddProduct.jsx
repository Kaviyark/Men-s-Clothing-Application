import React, { useState } from 'react';
import { push, ref as RTDBRef } from 'firebase/database';
import { db, storage } from '../../firebase'; // Import your Firebase Realtime Database
import Swal from 'sweetalert2';
import { ref as reference, put, getDownloadURL, uploadBytes } from "firebase/storage";


function generateRandomString(length) {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';

  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    result += characters.charAt(randomIndex);
  }

  return result;
}

const AddProduct = ({ AddProductComponent, fetchproducts }) => {
  const [files, setFiles] = useState([]);
  const [formData, setFormData] = useState({
    name: '',
    price: '',
    rank: '',
    measurement: '',

  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleFileChange = (e) => {
    const selectedFiles = Array.from(e.target.files);
    setFiles(selectedFiles);
  };

  const handleUpload = (e) => {
    Swal.fire({
      html: `
        <div className="p-5" >
          <div className="spinner-border text-dark" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      `,
      showConfirmButton: false,
      background: 'transparent',
    });
    e.preventDefault();

    if (files.length === 0) {
      Swal.fire({
        icon: 'error',
        title: 'No files selected',
        showConfirmButton: true,
        confirmButtonColor: 'black',
      });
      return;
    }

    const uploadPromises = files.map((file) => {
      const fileName = generateRandomString(10); // Generate a unique filename
      const imageRef = reference(storage, 'images/' + fileName);

      return uploadBytes(imageRef, file) // Use uploadBytes to upload the file to Firebase Storage
        .then((snapshot) => getDownloadURL(imageRef)) // Get the download URL
        .catch((error) => {
          throw error; // If an error occurs, propagate it for proper error handling
        });
    });

    Promise.all(uploadPromises)
      .then((downloadURLs) => {
        // Once all images are uploaded and you have their download URLs
        const dbRef = RTDBRef(db, 'products');
        const product = {
          name: formData.name,
          price: formData.price,
          rank: formData.rank,
          measurement: formData.measurement,
          productuniqueid: generateRandomString(10),
          images: downloadURLs, // Store the download URLs in the Realtime Database
        };

        push(dbRef, product);
        AddProductComponent();

        setFiles([]);
        setFormData({
          name: '',
          price: '',
          rank: '',
          measurement: '',
        });

        Swal.fire({
          icon: 'success',
          title: 'Upload Successful',
          showConfirmButton: true,
          confirmButtonColor: 'black',
        });
        fetchproducts();
      })
      .catch((error) => {
        Swal.fire({
          icon: 'error',
          title: 'Upload Unsuccessful',
          showConfirmButton: true,
          confirmButtonColor: 'black',
        });
        console.error('Error during file uploads:', error);
      });
  };

  return (
    <div>
      <form onSubmit={handleUpload}>
        <label className="ps-2 fw-bold mb-1" htmlFor="image">
          Images
        </label>
        <input type="file" onChange={handleFileChange} className="form-control mb-3" multiple required id="image" />
        <label className="ps-2 fw-bold mb-1" htmlFor="name">
          Product Name
        </label>
        <input
          placeholder="Enter the Product Name"
          type="text"
          onChange={handleChange}
          value={formData.name}
          name="name"
          id="name"
          className="form-control mb-3"
          required
        />
        <label className="ps-2 fw-bold mb-1" htmlFor="price">
          Product Price
        </label>
        <input
          placeholder="Enter the Product Price"
          type="text"
          onChange={handleChange}
          value={formData.price}
          name="price"
          id="price"
          className="form-control mb-3"
          required
        />
        <label className="ps-2 fw-bold mb-1" htmlFor="price">
          Product Measurement
        </label>
        <input
          placeholder="Enter the Product Measurement (piece,kg,g)"
          type="text"
          onChange={handleChange}
          value={formData.measurement}
          name="measurement"
          id="price"
          className="form-control mb-3"
          required
        />
        <label className="ps-2 fw-bold mb-1" htmlFor="rank">
          Product Rank
        </label>
        <input
          placeholder="Enter the Product Rank"
          type="number"
          onChange={handleChange}
          value={formData.rank}
          name="rank"
          id="rank"
          className="form-control mb-3"
          required
        />
        <button type="submit" className="btn btn-dark w-100">
          Upload
        </button>
      </form>
    </div>
  );
};

export default AddProduct;
