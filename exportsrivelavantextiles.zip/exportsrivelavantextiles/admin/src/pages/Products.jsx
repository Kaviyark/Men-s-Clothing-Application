import React, { useEffect, useState } from 'react';
import AddProduct from '../components/crud/AddProduct';
import { ref, child, get, remove, update } from 'firebase/database';
import { db, storage } from '../firebase';
import { deleteObject, ref as reference } from 'firebase/storage';
import Swal from 'sweetalert2';

const Products = () => {
  const [addproduct, setaddproduct] = useState(false);
  const [products, setProducts] = useState({});
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);




  useEffect(() => {
    const dbRef = ref(db);

    get(child(dbRef, 'products/'))
      .then((snapshot) => {
        if (snapshot.exists()) {
          const productData = snapshot.val();
          setProducts(productData);
        } else {
          console.log('No data available');
        }
      })
      .catch((error) => {
        console.error(error);
      });
  }, []);



  const AddProductComponent = () => {
    setaddproduct(!addproduct);
  };



  const fetchproducts = () => {
    const dbRef = ref(db);
    get(child(dbRef, 'products/'))
      .then((snapshot) => {
        if (snapshot.exists()) {
          const productData = snapshot.val();
          setProducts(productData);
        } else {
          console.log('No data available');
        }
      })
      .catch((error) => {
        console.error(error);
      });
  }







  const deleteProduct = (productId) => {
    Swal.fire({
      title: 'Delete Product',
      text: 'Are you sure you want to delete this product?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Delete',
      cancelButtonText: 'Cancel',
    }).then((result) => {
      if (result.isConfirmed) {
        if (typeof productId === 'string') {
          Swal.fire({
            html: `
              <div className="p-5" >
                <div className="spinner-border text-dark" role="status">
                  <span className="visually-hidden">Loading...</span>
                </div>
              </div>
            `,
            showConfirmButton: false,
            background: 'transparent',
          });

          const productRef = ref(db, `products/${productId}`);

          get(productRef)
            .then((snapshot) => {
              if (snapshot.exists()) {
                // Get the product data
                const productData = snapshot.val();
                const { images } = productData;

                // Remove the product from the RTDB first
                remove(productRef)
                  .then(() => {
                    setProducts((prevProducts) => {
                      const updatedProducts = { ...prevProducts };
                      delete updatedProducts[productId];
                      return updatedProducts;
                    });
                    Swal.fire('Deleted', 'The product has been deleted', 'success');

                    // Delete associated images from Firebase Storage
                    if (Array.isArray(images)) {
                      const deleteImagePromises = images.map((imageURL) => {
                        const imageRef = reference(storage, imageURL);
                        return deleteObject(imageRef);
                      });

                      Promise.all(deleteImagePromises)
                        .then(() => {
                          console.log('Deleted associated images from Firebase Storage');
                        })
                        .catch((error) => {
                          console.error('Error deleting images from Firebase Storage:', error);
                        });
                    }
                  })
                  .catch((error) => {
                    console.error('Error deleting product from RTDB:', error);
                    Swal.fire('Error', 'An error occurred while deleting the product', 'error');
                  });
              } else {
                console.log('Product data not found in RTDB');
                Swal.fire('Error', 'Product data not found in the database', 'error');
              }
            })
            .catch((error) => {
              console.error('Error fetching product data from RTDB:', error);
              Swal.fire('Error', 'An error occurred while fetching product data', 'error');
            });
        } else {
          console.error('Invalid product ID:', productId);
          Swal.fire('Error', 'Invalid product ID', 'error');
        }
      }
    });
  };



  const showProductModal = (product) => {
    setSelectedProduct(product);
    setIsViewModalOpen(true);
  };

  const closeViewModal = () => {
    setIsViewModalOpen(false);
    setSelectedProduct(null);
  };


  const [editedProductDetails, setEditedProductDetails] = useState({
    name: '',
    price: 0,
    measurement: '',
    rank: 0,
  });
  const [editProduct, setEditProduct] = useState(null);

  const openEditModal = (product) => {

    console.log(product)
    const dbRef = ref(db);
    get(child(dbRef, 'products/' + product))
      .then((snapshot) => {
        if (snapshot.exists()) {
          const productData = snapshot.val();
          console.log(productData)
          setEditProduct(productData)
          setEditedProductDetails({
            name: productData.name || '', // Use empty string if 'name' is undefined
            price: (productData.price || '').toString(), // Convert to string or use empty string
            measurement: productData.measurement || '', // Use empty string if 'measurement' is undefined
            rank: (productData.rank || '').toString(), // Convert to string or use empty string
            productspecialid: (product || '').toString(),
          });
        } else {
          console.log('No data available');
        }
      })


  };
  const saveEditedProduct = () => {
    Swal.fire({
      html: `
        <div class="p-5" >
          <div class="spinner-border text-dark" role="status">
            <span class="visually-hidden">Loading...</span>
          </div>
        </div>
      `,
      showConfirmButton: false,
      background: 'transparent',
    });
    if (editProduct) {
      const productRef = ref(db, `products/${editedProductDetails.productspecialid}`);
      const updatedProductDetails = { ...editedProductDetails };

      // Ensure that numeric values are parsed as numbers
      updatedProductDetails.price = parseFloat(updatedProductDetails.price);
      updatedProductDetails.rank = parseInt(updatedProductDetails.rank);

      update(productRef, updatedProductDetails)
        .then(() => {
          Swal.fire('Updated', 'The product has been updated', 'success');
          setEditProduct(null);
          setEditedProductDetails({
            name: '',
            price: '',
            measurement: '',
            rank: '',
            productspecialid: '', // Reset values to empty strings, including productspecialid
          });
          fetchproducts();
        })
        .catch((error) => {
          console.error('Error updating product:', error);
          Swal.fire('Error', 'An error occurred while updating the product', 'error');
        });
    }
  };

  return (
    <div>

      <div className="d-flex flex-row justify-content-between mb-5">
        <div>Products</div>
        <div>
          <button className="btn btn-dark btn-sm" onClick={AddProductComponent}>
            Add Products
          </button>
        </div>
      </div>

      <div className="container-fluid pb-4">
        <div className="row">
          {Object.keys(products)
            .sort((a, b) => products[a].rank - products[b].rank) // Sort products by rank
            .map((productId) => {
              const product = products[productId];
              return (
                <div className="col-12 col-lg-4 col-md-6" key={productId}>
                  <div className="card mb-4">
                    <div id={`carousel-${productId}`} className="carousel slide" data-bs-ride="carousel">
                      <div className="carousel-inner">
                        {product.images.map((image, imageIndex) => (
                          <div className={`carousel-item${imageIndex === 0 ? ' active' : ''}`} key={imageIndex}>
                            <img
                              src={image}
                              className=""
                              style={{ height: '50vh', width: '100%' }}
                              alt={`Product ${productId} Image ${imageIndex + 1}`}
                            />
                          </div>
                        ))}
                      </div>
                      <button
                        className="carousel-control-prev"
                        type="button"
                        data-bs-target={`#carousel-${productId}`}
                        data-bs-slide="prev"
                      >
                        <span className="carousel-control-prev-icon" aria-hidden="true" />
                        <span className="visually-hidden">Previous</span>
                      </button>
                      <button
                        className="carousel-control-next"
                        type="button"
                        data-bs-target={`#carousel-${productId}`}
                        data-bs-slide="next"
                      >
                        <span className="carousel-control-next-icon" ariahidden="true" />
                        <span className="visually-hidden">Next</span>
                      </button>
                    </div>
                    <div className="card-body">
                      <p className="card-text"><span className='fw-bold text-dark'>Name: </span>{product.name}</p>

                      <p className="card-text"><span className='fw-bold text-dark'>Price: </span> ₹{product.price}/{product.measurement}</p>
                      <p className="card-text"><span className='fw-bold text-dark'>Rank: </span> {product.rank}</p>
                      <p className="card-text"><span className='fw-bold text-dark'>Product ID: </span> {product.productuniqueid}</p>
                    </div>
                    <div className='d-flex flex-row justify-content-between px-3 pt-2'>
                      <h6 className='text-dark' onClick={() => openEditModal(productId)}>
                        <i className="bi bi-pencil-square" ></i> Edit
                      </h6>
                      <h6 onClick={() => deleteProduct(productId)} className='text-dark'>
                        <i className="bi bi-trash-fill"></i> Delete
                      </h6>
                      <h6 onClick={() => showProductModal(product)} className='text-dark'>
                        <i className="bi bi-eye-fill"></i> View
                      </h6>
                    </div>
                  </div>
                </div>
              );
            })}
        </div>
      </div>

      {addproduct && (
        <div>
          <div
            className="modal d-block border-0"
            role="dialog"
            style={{
              display: 'block',
              background: 'rgba(0, 0, 0, 0.5)',
              backdropFilter: 'blur(3px)',
            }}
          >
            <div className="modal-dialog modal-md border-0 modal-dialog-centered ">
              <div className="modal-content text-bg-green border-0 rounded-4">
                <div className="modal-body" >
                  <div className='d-flex flex-row justify-content-between pb-3'>
                    <h5 className='animate__animated animate__fadeInDown display-6 text-center'></h5>
                    <h5 className='animate__animated animate__fadeInDown display-6 text-center fw-bold'>
                      Add Products
                    </h5>
                    <h5 className='animate__animated animate__fadeInUp' onClick={AddProductComponent}>
                      <i className="bi bi-x-lg"></i>
                    </h5>
                  </div>
                  <div>
                    <AddProduct AddProductComponent={AddProductComponent} fetchproducts={fetchproducts} />
                  </div>
                  <div></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {isViewModalOpen && selectedProduct && (
        <div className="modal" style={{ display: 'block', background: 'rgba(0, 0, 0, 0.5)', backdropFilter: 'blur(3px)' }}>
          <div className="modal-dialog modal-lg" role="document">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">{selectedProduct.name}</h5>
                <button type="button" className="btn-close" aria-label="Close" onClick={closeViewModal}></button>
              </div>

              <div className="modal-body">
                <div className='d-flex flex-row justify-content-between px-2'>
                  <p>Price: ₹{selectedProduct.price} / {selectedProduct.measurement}</p>
                  <p>Rank: {selectedProduct.rank}</p>
                </div>
                <div className="row">
                  {selectedProduct.images.map((image, imageIndex) => (
                    <div key={imageIndex} className="col-12 col-lg-3">
                      <img
                        src={image}
                        className="img-fluid d-lg-block d-none mb-3"
                        style={{ height: '30vh', width: '100%' }}
                        alt={`Product View Image ${imageIndex + 1}`}
                      />

                      <img
                        src={image}
                        className="img-fluid d-lg-none d-block mb-3"
                        style={{ height: '50vh', width: '100%' }}
                        alt={`Product View Image ${imageIndex + 1}`}
                      />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}


      {editProduct && (
        <div className="modal" style={{ display: 'block', background: 'rgba(0, 0, 0, 0.5)', backdropFilter: 'blur(3px)' }}>
          <div className="modal-dialog modal-md border-0 modal-dialog-centered" role="document">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title fw-bold text-dark" >Edit Product</h5>
                <button type="button" className="btn-close" aria-label="Close" onClick={() => setEditProduct(null)}></button>
              </div>

              <div className="modal-body">
                <div className="form-group mb-3">
                  <label htmlFor="editName" className='fw-bold ps-1 mb-1 text-dark'>Name</label>
                  <input
                    type="text"
                    className="form-control"
                    id="editName"
                    value={editedProductDetails.name}
                    onChange={(e) =>
                      setEditedProductDetails({ ...editedProductDetails, name: e.target.value })
                    }
                  />
                </div>
                <div className="form-group mb-3">
                  <label htmlFor="editPrice" className='fw-bold ps-1 mb-1 text-dark'>Price</label>
                  <input
                    type="number"
                    className="form-control"
                    id="editPrice"
                    value={editedProductDetails.price}
                    onChange={(e) =>
                      setEditedProductDetails({ ...editedProductDetails, price: e.target.value })
                    }
                  />
                </div>
                <div className="form-group mb-3">
                  <label htmlFor="editMeasurement" className='fw-bold ps-1 mb-1 text-dark'>Measurement</label>
                  <input
                    type="text"
                    className="form-control"
                    id="editMeasurement"
                    value={editedProductDetails.measurement}
                    onChange={(e) =>
                      setEditedProductDetails({ ...editedProductDetails, measurement: e.target.value })
                    }
                  />
                </div>
                <div className="form-group mb-3">
                  <label htmlFor="editRank" className='fw-bold ps-1 mb-1 text-dark'>Rank</label>
                  <input
                    type="number"
                    className="form-control"
                    id="editRank"
                    value={editedProductDetails.rank}
                    onChange={(e) =>
                      setEditedProductDetails({ ...editedProductDetails, rank: e.target.value })

                    }
                  />
                </div>
                <button className="btn btn-dark w-100" onClick={saveEditedProduct}>
                  Update
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Products;
