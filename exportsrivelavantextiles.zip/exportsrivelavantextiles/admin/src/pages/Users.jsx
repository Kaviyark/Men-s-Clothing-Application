import React, { useEffect, useState } from 'react';
import DataTable from 'react-data-table-component'; // Import the DataTable component
import { db } from '../firebase';
import { ref, get } from 'firebase/database';

const Users = () => {
  const [users, setUsers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState('name');
  const [sortOrder, setSortOrder] = useState('asc');

  useEffect(() => {
    const usersRef = ref(db, 'users');
    const fetchUsers = async () => {
      try {
        const snapshot = await get(usersRef);
        if (snapshot.exists()) {
          const usersData = snapshot.val();
          const usersArray = Object.values(usersData);
          setUsers(usersArray);
        }
      } catch (error) {
        console.error('Error fetching users:', error);
      }
    };

    fetchUsers();
  }, []);

  const sortedUsers = users.sort((a, b) => {
    if (sortOrder === 'asc') {
      return a.profiledetails[sortBy] > b.profiledetails[sortBy] ? 1 : -1;
    } else {
      return a.profiledetails[sortBy] < b.profiledetails[sortBy] ? 1 : -1;
    }
  });

  const filteredUsers = sortedUsers.filter(
    (user) =>
      user.profiledetails.role === 'user' &&
      user.profiledetails.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const columns = [
    {
      name: 'Name',
      selector: 'profiledetails.name',
      sortable: true,
    },
    {
      name: 'Email',
      selector: 'profiledetails.email',
      sortable: true,
    },
    {
      name: 'Phone',
      selector: 'profiledetails.phone',
      sortable: true,
    },
    {
      name: 'Created At',
      cell: (row) => {
        const timestamp = row.profiledetails.accountcreatedat;
        if (timestamp) {
          const createdAtDate = new Date(timestamp); // Convert Firebase timestamp to JavaScript Date
          const localCreatedAt = createdAtDate.toLocaleString(); // Convert to local time
          return localCreatedAt;
        } else {
          return 'N/A';
        }
      },
      sortable: true,
    },
  ];
  

  return (
    <div>
      <div className='d-flex flex-row justify-content-between'>
        <div className='fw-bold'>
          Users
        </div>
        <div>
          {/* <button className='btn btn-danger btn-sm'>Export</button> */}
        </div>
      </div>
      <div>
        <input
          type="text"
          placeholder="Search by name"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className='form-control rounded-3 my-3'
        />
        <DataTable 
          title=""
          columns={columns}
          data={filteredUsers}
          defaultSortField="name"
          defaultSortAsc={true}
          pagination
          paginationPerPage={10}
          paginationRowsPerPageOptions={[10, 20, 30, 40, 50]}
          noHeader
          highlightOnHover
          pointerOnHover
          
        />
      </div>
    </div>
  );
}

export default Users;
