import React, { useEffect, useState } from 'react';
import DataTable from 'react-data-table-component';
import AddAdmins from '../components/auth/AddAdmins';
import { db } from '../firebase';
import { ref, get } from 'firebase/database';


const Admins = () => {
  const [addadmins, setAddAdmins] = useState(false);
  const [users, setUsers] = useState([]);
  const [adminUsers, setAdminUsers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState('name');
  const [sortOrder, setSortOrder] = useState('asc');

  useEffect(() => {
    const usersRef = ref(db, 'users');
    const fetchUsers = async () => {
      try {
        const snapshot = await get(usersRef);
        if (snapshot.exists()) {
          const usersData = snapshot.val();
          const usersArray = Object.values(usersData);
          setUsers(usersArray);
        }
      } catch (error) {
        console.error('Error fetching users:', error);
      }
    };

    fetchUsers();
  }, []);

  useEffect(() => {
    const filteredAdmins = users.filter((user) => user.profiledetails.role === 'admin');
    setAdminUsers(filteredAdmins);
  }, [users]);

  const handleSort = (field) => {
    if (sortBy === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortOrder('asc');
    }
  };

  const sortedAdmins = adminUsers.sort((a, b) => {
    if (sortOrder === 'asc') {
      return a.profiledetails[sortBy] > b.profiledetails[sortBy] ? 1 : -1;
    } else {
      return a.profiledetails[sortBy] < b.profiledetails[sortBy] ? 1 : -1;
    }
  });

  const filteredAdmins = sortedAdmins.filter((user) =>
    user.profiledetails.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const Addadmins = () => {
    setAddAdmins(!addadmins);
  };

  const columns = [
    {
      name: 'Name',
      selector: 'profiledetails.name',
      sortable: true,
    },
    {
      name: 'Email',
      selector: 'profiledetails.email',
      sortable: true,
    },
    {
      name: 'Phone',
      selector: 'profiledetails.phone',
      sortable: true,
    },
    {
      name: 'Created At',
      cell: (row) => {
        const timestamp = row.profiledetails.accountcreatedat;
        if (timestamp) {
          const createdAtDate = new Date(timestamp); // Convert Firebase timestamp to JavaScript Date
          const localCreatedAt = createdAtDate.toLocaleString(); // Convert to local time
          return localCreatedAt;
        } else {
          return 'N/A';
        }
      },
      sortable: true,
    },
  ];



  return (
    <div>
      <div className='d-flex flex-row justify-content-between'>
        <div>Admins</div>
        <div>
          <button onClick={Addadmins} className='btn btn-dark btn-sm'>
            Add Admins
          </button>
        </div>
      </div>
      <div>
        <input
          type="text"
          placeholder="Search by name"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className='form-control rounded-3 my-3'
        />
        <DataTable
          title=""
          columns={columns}
          data={filteredAdmins}
          defaultSortField="name"
          defaultSortAsc={true}
          pagination
          paginationPerPage={10}
          paginationRowsPerPageOptions={[10, 20, 30, 40, 50]}
          noHeader
          highlightOnHover
          pointerOnHover
          onSort={(column, direction) => handleSort(column.selector)}
        />
      </div>
      {addadmins && (
        <div className=''>
          <div
            className="modal d-block border-0"
            tabIndex="-1"
            role="dialog"
            style={{
              display: 'block',
              background: 'rgba(0, 0, 0, 0.5)',
              backdropFilter: 'blur(3px)',
            }}
          >
            <div className="modal-dialog modal-md border-0 modal-dialog-centered ">
              <div className="modal-content text-bg-green border-0 rounded-4">
                <div className="modal-body" >
                  <div className='d-flex flex-row justify-content-between pb-3'>
                    <h5 className='animate__animated animate__fadeInDown display-6 text-center'>

                    </h5>
                    <h5 className='animate__animated animate__fadeInDown display-6 text-center fw-bold text-dark'>
                      Add Admin
                    </h5>
                    <h5 className='animate__animated animate__fadeInUp' onClick={Addadmins}>
                      <i className="bi bi-x-lg"></i>
                    </h5>
                  </div>
                  <div>
                    <AddAdmins Addadmins={Addadmins} />
                  </div>
                  <div></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Admins;
