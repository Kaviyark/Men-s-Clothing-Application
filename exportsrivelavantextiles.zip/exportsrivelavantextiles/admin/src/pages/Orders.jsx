import { child, get, ref, update } from 'firebase/database';
import React, { useEffect, useState } from 'react';
import Swal from 'sweetalert2';
import { db } from '../firebase';

const Orders = () => {
  const [products, setProducts] = useState({});

  useEffect(() => {
    const dbRef = ref(db);

    // Fetch orders and filter by userUID
    get(child(dbRef, 'orders/'))
      .then((snapshot) => {
        const ordersData = snapshot.val();

        if (ordersData) {
          // Check if ordersData is an object
          if (typeof ordersData === 'object') {
            // Filter out orders with "Delivered" status
            const filteredOrders = Object.keys(ordersData).reduce((result, orderId) => {
              const order = ordersData[orderId];
              if (order && order.orderstatus !== 'Delivered') {
                result[orderId] = order;
              }
              return result;
            }, {});

            setProducts(filteredOrders);
          } else {
            // Handle the case where ordersData is not an object
            console.log('Invalid data format: ordersData is not an object');
            setProducts({});
          }
        } else {
          // Handle the case where ordersData is null or undefined
          console.log('No data available or invalid data format');
          setProducts({});
        }
      })
      .catch((error) => {
        console.error(error);
      });
  }, []);


  const fetchdata = () => {
    const dbRef = ref(db);

    // Fetch orders and filter by userUID
    get(child(dbRef, 'orders/'))
      .then((snapshot) => {
        const ordersData = snapshot.val();

        if (ordersData) {
          // Check if ordersData is an object
          if (typeof ordersData === 'object') {
            // Filter out orders with "Delivered" status
            const filteredOrders = Object.keys(ordersData).reduce((result, orderId) => {
              const order = ordersData[orderId];
              if (order && order.orderstatus !== 'Delivered') {
                result[orderId] = order;
              }
              return result;
            }, {});

            setProducts(filteredOrders);
          } else {
            // Handle the case where ordersData is not an object
            console.log('Invalid data format: ordersData is not an object');
            setProducts({});
          }
        } else {
          // Handle the case where ordersData is null or undefined
          console.log('No data available or invalid data format');
          setProducts({});
        }
      })
      .catch((error) => {
        console.error(error);
      });
  }


  function isImageUrl(value) {
    // You can customize this check based on your specific criteria.
    // For example, you can check for common image file extensions.
    return typeof value === 'string' && /\.(jpg|jpeg|png|gif|bmp)$/.test(value);
  }



  const handleOrderStatusChange = (productId, newStatus) => {
    const dbRef = ref(db, `orders/${productId}`);
    update(dbRef, { orderstatus: newStatus }, { merge: true });
    fetchdata()
  };

  return (
    <div>

      <div className='d-flex flex-column justify-content-between' style={{ height: "90vh", marginTop: "100px" }}>
        <div className='pt-4'>
          {Object.keys(products).length === 0 ? (
            <p className="text-center">No orders available.</p>
          ) : (
            <table className="table-responsive table">
              <thead>
                <tr>
                  <th scope="col">Payment Method</th>
                  <th scope="col">Porduct Size</th>
                  <th scope="col">Total Price</th>
                  <th scope="col">Order Status</th>
                  <th scope="col">Quantity</th>

                  <th scope="col">UserData</th>
                  <th scope="col">Product Details</th>
                  <th scope="col">Measurement Details</th>
                </tr>
              </thead>
              <tbody>
                {Object.keys(products)
                  .sort((a, b) => products[a].rank - products[b].rank)
                  .map((productId) => {
                    const product = products[productId];
                    return (
                      <tr key={productId}>

                        <td>        {product.selectedPaymentMethod}</td>
                        <td>        {product.selectedSize}</td>
                        <td>     ₹   {product.totalPrice}</td>


                        <td>
                          <div className="dropdown">
                            <button
                              className="btn btn-secondary dropdown-toggle"
                              type="button"
                              id="orderStatusDropdown"
                              data-bs-toggle="dropdown"
                              aria-expanded="false"
                            >
                              {product.orderstatus}
                            </button>
                            <ul className="dropdown-menu" aria-labelledby="orderStatusDropdown">
                              <li>
                                <button
                                  className="dropdown-item"
                                  onClick={() => handleOrderStatusChange(productId, "Processing")}
                                >
                                  Processing
                                </button>
                              </li>
                              <li>
                                <button
                                  className="dropdown-item"
                                  onClick={() => handleOrderStatusChange(productId, "Order Picked Up")}
                                >
                                  Order Picked Up
                                </button>
                              </li>
                              <li>
                                <button
                                  className="dropdown-item"
                                  onClick={() => handleOrderStatusChange(productId, "On the Way")}
                                >
                                  On the Way
                                </button>
                              </li>
                              <li>
                                <button
                                  className="dropdown-item"
                                  onClick={() => handleOrderStatusChange(productId, "Delivered")}
                                >
                                  Delivered
                                </button>
                              </li>
                            </ul>
                          </div>
                        </td>

                        <td>{product.quantity}</td>
                        <td>
                          <table className="table">
                            <thead>
                              <tr>
                                <th scope="col">Property</th>
                                <th scope="col">Value</th>
                              </tr>
                            </thead>
                            <tbody>
                              {Object.entries(product.userData).map(([key, value]) => (
                                <tr key={key}>
                                  <td>{key}</td>
                                  <td>{value}</td>
                                </tr>
                              ))}
                            </tbody>


                          </table>
                        </td>
                        <td>
                          <td>
                            <td>
                              <table className="table">
                                <thead>
                                  <tr>
                                    <th scope="col">Property</th>
                                    <th scope="col">Value</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {Object.entries(product.product).map(([key, value]) => (
                                    key !== 'images' && (
                                      <tr key={key}>
                                        <td>{key}</td>
                                        <td>
                                          {isImageUrl(value) ? (
                                            <a href={value} target="_blank" rel="noopener noreferrer">
                                              <img src={value} alt="Image" />
                                            </a>
                                          ) : (
                                            value
                                          )}
                                        </td>
                                      </tr>
                                    )
                                  ))}
                                </tbody>
                              </table>
                            </td>

                          </td>

                        </td>
                        <td>
                          <table className="table">
                            <thead>
                              <tr>
                                <th scope="col">Property</th>
                                <th scope="col">Value</th>
                              </tr>
                            </thead>
                            <tbody>
                              {product.customInputs && Object.entries(product.customInputs).map(([key, value]) => (
                                <tr key={key}>
                                  <td>{key}</td>
                                  <td>{value}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>

                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}

export default Orders;
