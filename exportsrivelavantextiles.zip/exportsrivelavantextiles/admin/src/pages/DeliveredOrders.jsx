import { child, get, ref, update } from 'firebase/database';
import React, { useEffect, useState } from 'react';
import Swal from 'sweetalert2';
import { db } from '../firebase';

const DeliveredOrders = () => {
  const [products, setProducts] = useState({});

  useEffect(() => {
    const dbRef = ref(db);

    // Fetch orders and filter by userUID
    get(child(dbRef, 'orders/'))
      .then((snapshot) => {
        if (snapshot.exists()) {
          const ordersData = snapshot.val();

          // Filter orders with "Delivered" status
          const deliveredOrders = Object.keys(ordersData).reduce((result, productId) => {
            if (ordersData[productId].orderstatus === 'Delivered') {
              result[productId] = ordersData[productId];
            }
            return result;
          }, {});

          setProducts(deliveredOrders);
        } else {
          console.log('No delivered orders available');
        }
      })
      .catch((error) => {
        console.error(error);
      });
  }, []);

  const fetchdata = () => {
    const dbRef = ref(db);

    // Fetch orders and filter by userUID
    get(child(dbRef, 'orders/'))
      .then((snapshot) => {
        if (snapshot.exists()) {
          const ordersData = snapshot.val();

          setProducts(ordersData);
        } else {
          console.log('No data available');
        }
      })
      .catch((error) => {
        console.error(error);
      });
  };

  return (
    <div>
      <div className='d-flex flex-column justify-content-between' style={{ height: "90vh", marginTop: "100px" }}>
        <div className='pt-4'>
          {Object.keys(products).length === 0 ? (
            <p className="text-center">No delivered orders available.</p>
          ) : (
            <table className="table">
              <thead>
                <tr>
                  <th scope="col">Name</th>
                  <th scope="col">Price</th>
                  <th scope="col">Order Status</th>
                  <th scope="col">Quantity</th>
                  <th scope="col">UserData</th>
                </tr>
              </thead>
              <tbody>
                {Object.keys(products)
                  .sort((a, b) => products[a].rank - products[b].rank)
                  .map((productId) => {
                    const product = products[productId];
                    return (
                      <tr key={productId}>
                        <td>{product.name}</td>
                        <td>₹{product.price}/{product.measurement}</td>
                        <td>{product.orderstatus}</td>
                        <td>{product.quantity}</td>
                        <td>
                          <table className="table">
                            <thead>
                              <tr>
                                <th scope="col">Key</th>
                                <th scope="col">Value</th>
                              </tr>
                            </thead>
                            <tbody>
                              {Object.entries(product.userData).map(([key, value]) => (
                                <tr key={key}>
                                  <td>{key}</td>
                                  <td>{value}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}

export default DeliveredOrders;
